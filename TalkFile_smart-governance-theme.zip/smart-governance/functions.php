<?php
if (!defined('ABSPATH')) { exit; }
add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('responsive-embeds');
    add_theme_support('automatic-feed-links');
    add_theme_support('html5', array('search-form','comment-form','comment-list','gallery','caption','style','script'));
    register_nav_menus(array('primary'=>'주 메뉴'));
});
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('smart-governance', get_stylesheet_uri(), array(), '1.0.0');
    wp_enqueue_script('smart-governance-language', get_template_directory_uri().'/language.js', array(), '1.0.0', true);
});
add_action('customize_register', function ($c) {
    $c->add_section('sg_home', array('title'=>'연구소·학과 홈페이지','priority'=>30));
    $fields=array(
        'institute'=>array('연구소 명칭','스마트거버넌스정책연구소','text','sanitize_text_field'),
        'department'=>array('학과 명칭','스마트거버넌스행정학과','text','sanitize_text_field'),
        'intro'=>array('첫 화면 소개문','스마트거버넌스정책연구소와 학과를 연결하는 연구·교육 플랫폼. 기술의 변화를 공공의 가치로 이어가는 길을 탐구합니다.','textarea','sanitize_textarea_field'),
        'email'=>array('공식 이메일','','email','sanitize_email'),
        'phone'=>array('전화번호','','text','sanitize_text_field'),
        'address'=>array('위치 및 주소','','textarea','sanitize_textarea_field')
    );
    foreach ($fields as $key=>$v) {
        $c->add_setting('sg_'.$key, array('default'=>$v[1],'sanitize_callback'=>$v[3]));
        $c->add_control('sg_'.$key, array('label'=>$v[0],'section'=>'sg_home','type'=>$v[2]));
    }
});
